﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InitalLoadScript : MonoBehaviour
{
    public GameObject txtPassword;
    public GameObject txtUsename;
    public GameObject txtRetype;
    public GameObject PasswordText;
    public GameObject UsernameText;
    public GameObject RetypeText;
    public InputField RetypeT;
    public string Retpye;

    /* used to hide textboxes and text when the game is first opened */
    void Start()
    {
        txtPassword.SetActive(false);
        txtUsename.SetActive(false);
        txtRetype.SetActive(false);
        PasswordText.SetActive(false);
        UsernameText.SetActive(false);
        RetypeText.SetActive(false);
        Retpye = RetypeT.text;
    }


}
