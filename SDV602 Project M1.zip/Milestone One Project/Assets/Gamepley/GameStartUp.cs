﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameStartUp : MonoBehaviour
{
    public GameObject StartButton;

    public void HideBUtton()
    {
        StartButton.SetActive(false);
    }

}
