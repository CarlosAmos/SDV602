﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DialogueManager : MonoBehaviour
{

    public Text nameText;
    public Text dialogueText;

    private Queue<string> sentences;

    /* FOr when the app starts up */
    void Start()
    {
        dialogueText.text = "Welcome to Into Darkness, before you get started, you will need to know how to play." +
            " You can press the Continue Button down below to continue the story and you can press the Back to Menu button to return to the menu."
            + " At some point during the story you will need to answer a question, riddle or puzzle, you can enter your answer in the textbox below."
            + " When you are ready to begin, press the Start Game button.";
        
        sentences = new Queue<string>();
    }

    /* User presses Start Game button. Starts the story */
    public void StartDialogue (Dialogue dialogue)
    {
        Debug.Log("Start Dialog");
        nameText.text = dialogue.name;

        sentences.Clear();

        foreach (string sentence in dialogue.sentences)
        {
            sentences.Enqueue(sentence);
        }

        DisplayNextSentence();
    }

    /* When the user presses the Continue button, this will get the next sentence */
    public void DisplayNextSentence()
    {
        if(sentences.Count == 0)
        {
            EndDialogue();
            return;
        }

        string sentence = sentences.Dequeue();
        dialogueText.text = sentence;
    }

    /* For when the story/game is finished */
    void EndDialogue()
    {
        Debug.Log("End of Dialogue");
    }
}
