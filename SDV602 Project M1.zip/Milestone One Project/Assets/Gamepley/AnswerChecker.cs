﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AnswerChecker : MonoBehaviour
{
    public GameObject btnContinue;
    public GameObject btnCheckAnswer;
    public GameObject txtAnswerField;

    public Text DialogueT;
    public string Dialogue;
    public InputField AnswerT;
    public string Answer;

    /* User presses continue button, this checks the dialogue for an encounter */

    public void CheckEncounter()
    {
        Dialogue = DialogueT.text;
        if (Dialogue == "What is 2 + 2?")
        {
            btnContinue.SetActive(false);
        }
        else
        {
            Debug.Log("Continue Story");
        }
    }

    /* Check is the answer is correct */

    public void CheckAnswer()
    {
        Dialogue = DialogueT.text;
        Answer = AnswerT.text;

        if (Dialogue == "What is 2 + 2?" && Answer == "4")
        {
           Debug.Log("Answer Correct");
            btnCheckAnswer.SetActive(false);
            btnContinue.SetActive(true);
        }
        else
        {
            Debug.Log("Answer Wrong");
            btnContinue.SetActive(true);
        }
    }
}
