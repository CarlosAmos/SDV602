﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EncounterManager
{
    private DataService Db = new DataService("IntoDarkness");
    public DataService DB
    {
        get
        {
            return Db;
        }
    }

    /*public GetEncounter()
    {

    }*/


}

