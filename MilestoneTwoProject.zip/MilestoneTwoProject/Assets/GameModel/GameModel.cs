﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public static class GameModel 
{
    private static PlayerManager _playerManager;
    private static StoryManager _storyManager;

    public static StoryManager Story
    {
        get { return _storyManager; }
    }

    public static PlayerManager PlayerManager
    {
        get { return _playerManager; }
    }

    public static List<Canvas> ViewRenders = new List<Canvas>();

    public static void ShowCanvas(Canvas pCanvas)
    {
        pCanvas.enabled = true;

        ViewRenders.Where(x =>
        {
            if (x.name != pCanvas.name)
            {
                x.enabled = false;
                return true;
            }
            else
                return false;
        }).ToList<Canvas>();
    }

    static GameModel()
    {
        _storyManager = new StoryManager();
        _playerManager = new PlayerManager();
            
    }
}
