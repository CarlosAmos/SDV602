﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{


    public string username;
    public string password;


    //Not using
    #region Views

    public Canvas Menu;
    public Canvas Navigator;
    #endregion

    //
    #region Text Inputs and outputs

    public Text Username;
    public Text Password;

    public Text ScoreDisplay;

    #endregion
    //Not using
    #region DisplayControl

    public void SwitchTo(Canvas pCanvas)
    {
        GameModel.ShowCanvas(pCanvas);
    }

    #endregion

    //This is used to check if the password is correct
    #region Password Proccessing


    public void CheckPassword()
    {
        CheckPassword(Username.text, Password.text);
    }
    public void CheckPassword(string pUsername, string pPassword)
    {
        if ( GameModel.PlayerManager.Login(pUsername,pPassword))
        {
            Navigator.enabled = true;
        }
        else
        {
            if (GameModel.PlayerManager.PlayerExists(pUsername))
            {
                Navigator.enabled = false;
                SwitchTo(Menu);
            }
            else
            {
                

                    Navigator.enabled = true;
                   
                
            }
        }
    }

    #endregion
}
