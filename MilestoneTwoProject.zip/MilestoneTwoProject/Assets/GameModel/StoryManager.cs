﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoryManager 
{
    private DataService Db = new DataService("IntoDarkness.db");

    public DataService DB
    {
        get
        {
            return Db;
        }
    }

    public StoryManager()
    {
        Db.CreateDB(new[]
        {
            typeof(Player),
        });
    }
}
