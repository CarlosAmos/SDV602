﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LoginManager : MonoBehaviour
{
    #region Inputs and Outputs
    public Text Username;
    public Text Password;
    public Text Retype;
    public Text StatusText;
    #endregion


    //Handle the logins
    #region Login Handler
    public void handleLogin()
    {
        handleLogin(Username.text, Password.text);
    }

    public void handleLogin(string pUsername, string pPassword)
    {
        if (GameModel.PlayerManager.Login(pUsername, pPassword))
        {
            SceneManager.LoadScene(1);
        }
        else
        {
            StatusText.text = "Password or username is incorrect";
        }
    }
    #endregion


    //Handle registering players
    #region Register Handler
    public void handleRegistration()
    {
        handleRegistration(Username.text, Password.text);
    }

    public void handleRegistration(string pUsername, string pPassword)
    {
        if(Password.text == Retype.text)
        {
            if (GameModel.PlayerManager.RegisterPlayer(pUsername, pPassword))
            {
                StatusText.text = "User successfully created";
            }
            else
            {
                StatusText.text = "User already exists";
            }
        }
        else
        {
            StatusText.text = "Passwords do not match";
        }
     

    }
    #endregion
}
