﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SQLite4Unity3d;
using System.Linq;

public class PlayerManager
{

    private DataService Db = new DataService("IntoDarkness.db");
    public bool LoggedIn = false;

    public DataService DB
    {
        get
        {
            return Db;
        }
    }

    public PlayerManager()
    {
        DB.CreateDB(new[]
        {
            typeof(Player),
        });
    }

    public bool PlayerExists(string pUsername)
    {
        return
            (Db.Connection.Table<Player>().Where<Player>(
                x => x.Username == pUsername
                ).ToList<Player>().Count > 0);
    }

    public bool RegisterPlayer(string pUsername, string pPassword)
    {
        bool result = false;

        if ( !PlayerExists(pUsername) )
        {
            Player newPlayer = new Player
            {
                Username = pUsername,
                Password = pPassword,
            };
            
            Db.Connection.Insert(newPlayer);

            result = true;
        }

        return result;

    }

    public bool Login(string pUsername, string pPassword)
    {
        List<Player> lcUser = Db.Connection.Table<Player>().Where<Player>(
            x => x.Username == pUsername && x.Password == pPassword
            ).ToList<Player>();

        bool result = lcUser.Count > 0;
        if (!result)
        {
            
        }
        else
        {
            
        }

        LoggedIn = result;

        return result;
    }





}
