﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Cheats : MonoBehaviour
{
    public Text txtPoints;

    public InputField AnswerT;
    public string Answer;



    public void OpenCheats()
    {
        Answer = AnswerT.text;
        Answer = "Enter amount of points";

        Debug.Log("Add Cheats");
    }

    public void AddCheatPoints()
    {
        

        Answer = AnswerT.text;

        txtPoints.text = Answer;
        Debug.Log("Added Points to player");
    }

}
