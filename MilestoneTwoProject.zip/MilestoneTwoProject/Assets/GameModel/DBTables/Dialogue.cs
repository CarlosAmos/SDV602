﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SQLite4Unity3d;

public class Dialogue 
{
    [PrimaryKey]
    public string ID { get; set; }
    public string DialogueText { get; set; }
}
