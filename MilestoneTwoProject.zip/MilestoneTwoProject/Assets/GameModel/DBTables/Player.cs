﻿using SQLite4Unity3d;

public class Player 
{
    [PrimaryKey]
    public string Username { get; set; }
    public string Password { get; set; }
}
