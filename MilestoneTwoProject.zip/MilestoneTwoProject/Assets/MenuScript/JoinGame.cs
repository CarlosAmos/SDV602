﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JoinGame : MonoBehaviour
{

    public void GetGameList()
    {
        Debug.Log("There are currently no games running");
    }

}
