﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RegisterScript : MonoBehaviour
{
    public GameObject txtPassword;
    public GameObject txtUsename;
    public GameObject txtRetype;
    public GameObject PasswordText;
    public GameObject UsernameText;
    public GameObject RetypeText;

    public InputField PasswordT;
    public string Password;
    public InputField UsernameT;
    public string Username;
    public InputField RetypeT;
    public string Retpye;
  


    public void OpenButton()
    {

        txtPassword.SetActive(true);
        txtUsename.SetActive(true);
        txtRetype.SetActive(true);
        PasswordText.SetActive(true);
        UsernameText.SetActive(true);
        RetypeText.SetActive(true);
        
    }

    
    /* For resgistering a new user */
    public void Register()
    {
        /* This is for testing only */
        Password = PasswordT.text;
        Username = UsernameT.text;
        Retpye = RetypeT.text;

        if(Username == "" && Password == "" && Retpye == "")
        {
            Debug.Log("Register");
        }
        else
        {
            if (Username == "Testing123")
            {
                Debug.Log("User already exists");
            }
            else if (Password == Retpye)
            {
                Debug.Log("Account Added to database");
                txtRetype.SetActive(false);
                RetypeText.SetActive(false);
            }
            else
            {
                Debug.Log("Passwords don't match");
            }
        }
    }
}