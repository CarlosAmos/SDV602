﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LoginScript : MonoBehaviour
{

    private DataService DB = new DataService("Users.db");
    public bool LoggedIn = false;

    public GameObject txtPassword;
    public GameObject txtUsename;
    public GameObject PasswordText;
    public GameObject UsernameText;

    public InputField PasswordT;
    public string Password;
    public InputField UsernameT;
    public string Username;


    /* Show input textboxes and test */
    public void OpenButton()
    {

        txtPassword.SetActive(true);
        txtUsename.SetActive(true);
        PasswordText.SetActive(true);
        UsernameText.SetActive(true);

    }

    /* When player has entered details and wants to login */

    public void Login()
    {
        /* This is for testing only */
        /*Password = PasswordT.text;
        Username = UsernameT.text;
        if (Password == "Password" && Username == "Account2")
        {
            SceneManager.LoadScene(1);
            Debug.Log("Login Successful");
        }
        else
        {
            Debug.Log("Username or password are incorrect");
     }*/

    //Check if account is correct
     }

}
